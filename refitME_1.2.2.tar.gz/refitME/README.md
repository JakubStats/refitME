# refitME
Monte Carlo Expectation Maximization - A measurement error modelling wrapper function for lm, glm and gam model objects.

An R-package for methods developed in:

Stoklosa, J., Hwang, W-H., and Warton, D.I. refitME: Measurement Error Modelling using Monte Carlo Expectation Maximization in R.
