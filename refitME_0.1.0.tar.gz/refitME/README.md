# refitME
Monte Carlo Expectation Maximization - A measurement error modelling wrapper function for lm, glm and gam model objects.

An R-package for methods developed in:

Stoklosa, J., Hwang, W-H., and Warton, D.I. (2019). A general algorithm for error-in-variables modelling using Monte Carlo expectation maximization.
