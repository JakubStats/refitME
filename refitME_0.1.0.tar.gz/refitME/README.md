# refitME
Monte Carlo Expectation Maximixation - A measurement error modelling wrapper function

A new R-package!
