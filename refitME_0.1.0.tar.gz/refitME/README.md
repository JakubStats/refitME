# refitME
Monte Carlo Expectation Maximixation - A measurement error modelling wrapper function for lm, glm and gam model objects.

A new R-package!
