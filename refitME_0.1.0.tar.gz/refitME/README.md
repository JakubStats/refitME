# refitME
Monte Carlo Expectation Maximixation - A measurement error modelling wrapper function for lm, glm and gam model objects.

A new R-package for:

Stoklosa, J. and Warton, D.I. (2019). A general algorithm for error-in-variables using Monte Carlo expectation maximization.
